/** Automatically generated file. DO NOT MODIFY */
package yuqian.androidmanager;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}