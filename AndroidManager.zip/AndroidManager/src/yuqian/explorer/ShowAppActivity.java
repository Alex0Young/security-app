package yuqian.explorer;

import java.util.ArrayList;
import java.util.List;

import yuqian.androidmanager.R;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class ShowAppActivity extends Activity implements Runnable ,OnItemClickListener {
	
	private static final int SEARCH_APP = 0;
	private static final int DELETE_APP = 1;
	
	GridView gv;
	
	ListView lv;
	
	private List<PackageInfo> packageInfos;
	
	private List<PackageInfo> userPackageInfos;
	
	private List<PackageInfo> showPackageInfos;
	
	private ProgressDialog pd;
	
	ImageButton ib_change_category;
	ImageButton ib_change_view;
	
	private boolean allApplication = true;
	private boolean isListView = false;
	
	private Handler mHandler = new Handler(){

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if(msg.what == SEARCH_APP) {
				showPackageInfos = packageInfos;
				gv.setAdapter(new GridViewAdapter(ShowAppActivity.this,showPackageInfos));
				lv.setAdapter(new ListViewAdapter(ShowAppActivity.this,showPackageInfos));
				pd.dismiss();
				setProgressBarIndeterminateVisibility(false);
			}
			
			if(msg.what == DELETE_APP) {
				System.out.println("Delete App Success!!");
			}
			
		}
		
		
	};
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
       // requestWindowFeature(Window.FEATURE_NO_TITLE);
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        setContentView(R.layout.show_app_grid);
        setProgressBarIndeterminateVisibility(true);
        
        AnimationSet set = new AnimationSet(false);
        Animation animation = new AlphaAnimation(0, 0);
        
      //Animation animation = new AlphaAnimation(0,1);
        animation.setDuration(0);
        set.addAnimation(animation);
        /*
        animation = new TranslateAnimation(1, 13, 10, 50);
        animation.setDuration(300);
        set.addAnimation(animation);*/
        
       /* animation = new RotateAnimation(30,10);
        animation.setDuration(300);
        set.addAnimation(animation);*/
        /*
        animation = new ScaleAnimation(5,0,2,0);
        animation.setDuration(300);
        set.addAnimation(animation);*/
        
        LayoutAnimationController controller = new LayoutAnimationController(set, 1);
        
        
        gv = (GridView) this.findViewById(R.id.gv_apps);
        gv.setLayoutAnimation(controller);
        
        lv = (ListView)this.findViewById(R.id.lv_apps);
        lv.setLayoutAnimation(controller);
        lv.setCacheColorHint(0);
        gv.setOnItemClickListener(this);
        lv.setOnItemClickListener(this);
        
        ib_change_category = (ImageButton) this.findViewById(R.id.ib_change_category);
        ib_change_view = (ImageButton) this.findViewById(R.id.ib_change_view);
        ib_change_view.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				if(isListView) {
					MyToast.myToastShow(ShowAppActivity.this, R.drawable.grids, "������ʾ", Toast.LENGTH_SHORT);
					ib_change_view.setImageResource(R.drawable.grids);
					//ʵ���б���������л�
					lv.setVisibility(View.GONE);
					gv.setVisibility(View.VISIBLE);
					
					
					//AlphaAnimation ���ƽ���͸���Ķ���Ч��
					//ScaleAnimation ���Ƴߴ������Ķ���Ч��
					//TranslateAnimation  ���ƻ���ƽ�ƵĶ���Ч��
					//RotateAnimation  ���ƻ���Ƕȱ仯�Ķ���Ч��
					//LayoutAnimation  ��ȾViewGroup��ÿ��View��ʾʱ��Ķ���Ч��
					
					AnimationSet  set = new AnimationSet(false);
					Animation animation = new RotateAnimation(60, 0);
					animation.setInterpolator(ShowAppActivity.this, android.R.anim.overshoot_interpolator);
					animation.setDuration(0);//����ʱ�������  
					set.addAnimation(animation);//���붯������   
					animation = new AlphaAnimation(0, 1);
					animation.setDuration(0);
					set.addAnimation(animation);
					gv.startAnimation(set);
					gv.startLayoutAnimation();
					
					
					isListView  = false;
				} else {
					MyToast.myToastShow(ShowAppActivity.this, R.drawable.list, "�б���ʾ", Toast.LENGTH_SHORT);
					ib_change_view.setImageResource(R.drawable.list);
					//ʵ���б���������л�
					gv.setVisibility(View.GONE);
					lv.setVisibility(View.VISIBLE);
					
					AnimationSet set = new AnimationSet(false);

					Animation animation = new TranslateAnimation(200, 1, 200, 1);
					animation.setDuration(0);
					animation.setInterpolator(ShowAppActivity.this, android.R.anim.bounce_interpolator);
					set.addAnimation(animation);
					
					animation = new ScaleAnimation(0, 1, 0, 1);
					animation.setDuration(0);
					set.addAnimation(animation);
					lv.startAnimation(set);
					isListView = true;
				}
				
			}
        	
        });
        
        
        //�û���װ�����б������г����б��л�
        ib_change_category.setOnClickListener(new OnClickListener(){
			public void onClick(View v) {
				if(allApplication) {
					ib_change_category.setImageResource(R.drawable.user);
					showPackageInfos = userPackageInfos;
					allApplication = false;
					MyToast.myToastShow(ShowAppActivity.this, R.drawable.user, "�û���װ�ĳ����б�", Toast.LENGTH_SHORT);
				} else {
					ib_change_category.setImageResource(R.drawable.all);
					showPackageInfos = packageInfos;
					allApplication = true;
					MyToast.myToastShow(ShowAppActivity.this, R.drawable.all, "���г����б�", Toast.LENGTH_SHORT);
				}
				//֧��������б���ʽ
				gv.setAdapter(new GridViewAdapter(ShowAppActivity.this,showPackageInfos));
				lv.setAdapter(new ListViewAdapter(ShowAppActivity.this,showPackageInfos));
				
			}});
        pd = ProgressDialog.show(this, "���Ժ�...", "��������������װ��Ӧ�ó���...",true,false);
        Thread t = new Thread(this);
        t.start();
        
    }
    
    
    
    class GridViewAdapter extends BaseAdapter {
    	
    	LayoutInflater inflater;
    	List<PackageInfo> pkInfos;
    	
    	public GridViewAdapter(Context context,List<PackageInfo> packageInfos) {
    		inflater = LayoutInflater.from(context);
    		this.pkInfos = packageInfos;
    	}

		public int getCount() {
			// TODO Auto-generated method stub
			return pkInfos.size();
		}

		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return pkInfos.get(arg0);
		}

		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			View view = inflater.inflate(R.layout.gv_item, null);
			TextView tv = (TextView) view.findViewById(R.id.gv_item_appname);
			ImageView iv = (ImageView) view.findViewById(R.id.gv_item_icon);
			
			//tv.setText(packageInfos.get(position).packageName);
			tv.setText(pkInfos.get(position).applicationInfo.loadLabel(getPackageManager()));
			
			iv.setImageDrawable(pkInfos.get(position).applicationInfo.loadIcon(getPackageManager()));
			
			return view;

		}
    	
    }

    class ListViewAdapter extends BaseAdapter {
    	LayoutInflater inflater;
    	List<PackageInfo> pkInfos;
    	
    	public ListViewAdapter(Context context,List<PackageInfo> packageInfos) {
    		inflater = LayoutInflater.from(context);
    		this.pkInfos = packageInfos;
    	}

		public int getCount() {
			// TODO Auto-generated method stub
			return pkInfos.size();
		}

		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return pkInfos.get(arg0);
		}

		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			View view = inflater.inflate(R.layout.lv_item, null);
			TextView tv_appname = (TextView) view.findViewById(R.id.lv_item_appname);
			TextView tv_packagename = (TextView) view.findViewById(R.id.lv_item_packageame);
			ImageView iv = (ImageView) view.findViewById(R.id.lv_icon);
			
			//tv.setText(packageInfos.get(position).packageName);
			tv_appname.setText(pkInfos.get(position).applicationInfo.loadLabel(getPackageManager()));
			tv_packagename.setText(pkInfos.get(position).packageName);
			iv.setImageDrawable(pkInfos.get(position).applicationInfo.loadIcon(getPackageManager()));
			
			return view;
		}
    }
    
    //�߳��л�ȡϵͳӦ�ó��򣬲�����ɸѡ���û���װ��Ӧ�ó���
	public void run() {
		packageInfos = getPackageManager().getInstalledPackages(PackageManager.GET_UNINSTALLED_PACKAGES | PackageManager.GET_ACTIVITIES);
		userPackageInfos = new ArrayList<PackageInfo>();
		for(int i=0;i<packageInfos.size();i++) {
			
			PackageInfo temp = packageInfos.get(i);
			ApplicationInfo appInfo = temp.applicationInfo;
			boolean flag = false;
			if((appInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
				 // Updated system app
				flag = true;
			} else if((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
				// Non-system app
				flag = true;
			}
			if(flag) {
				userPackageInfos.add(temp);
			}
		}
		
		try {
			Thread.currentThread().sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mHandler.sendEmptyMessage(SEARCH_APP);
		
		try {
			Thread.currentThread().sleep(2500);
			mHandler.sendEmptyMessage(DELETE_APP);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	//�����Ӧ�ó���ͼ��ʱ����ʾѡ�����
	public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3) {
		final PackageInfo tempPkInfo = showPackageInfos.get(position);
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("ѡ��");
		builder.setItems(R.array.choice,new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog, int which) {
				switch (which) {
				case 0:
					String packageName = tempPkInfo.packageName;
					ActivityInfo activityInfo = tempPkInfo.activities[0];
					String activityName = activityInfo.name;
					Intent intent = new Intent();
					intent.setComponent(new ComponentName(packageName,activityName));
					startActivity(intent);
					
					break;
				case 1:
					showAppDetail(tempPkInfo);
					break;
				case 2:
					Uri packageUri = Uri.parse("package:" + tempPkInfo.packageName);
					Intent deleteIntent = new Intent();
					deleteIntent.setAction(Intent.ACTION_DELETE);
					deleteIntent.setData(packageUri);
					startActivityForResult(deleteIntent, 0);
					break;
				}
				
			}
		});
		builder.setNegativeButton("ȡ��", null);
		builder.create().show();
		
	}
	
	
	
	//��ȡϵͳӦ�ó��򣬲�����ɸѡ���û���װ��Ӧ�ó���
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		packageInfos = getPackageManager().getInstalledPackages(PackageManager.GET_UNINSTALLED_PACKAGES | PackageManager.GET_ACTIVITIES);
		userPackageInfos = new ArrayList<PackageInfo>();
		for(int i=0;i<packageInfos.size();i++) {
			
			PackageInfo temp = packageInfos.get(i);
			ApplicationInfo appInfo = temp.applicationInfo;
			boolean flag = false;
			if((appInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
				 // Updated system app
				flag = true;
			} else if((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
				// Non-system app
				flag = true;
			}
			if(flag) {
				userPackageInfos.add(temp);
			}
		}
		
		if(allApplication) {
			showPackageInfos = packageInfos;
		} else {
			showPackageInfos = userPackageInfos;
		}
		
		gv.setAdapter(new GridViewAdapter(ShowAppActivity.this,showPackageInfos));
		lv.setAdapter(new ListViewAdapter(ShowAppActivity.this,showPackageInfos));
		
		
	}
	
	
	@Override
	protected void onResume() {
		super.onResume();
	}
	
	//��ʾ��ϸ��Ϣ
	private void showAppDetail(PackageInfo packageInfo) {
		
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("��ϸ��Ϣ");
		StringBuffer message = new StringBuffer();
		message.append("��������:" + packageInfo.applicationInfo.loadLabel(getPackageManager()));
		message.append("\n ����:" + packageInfo.packageName);
		message.append("\n �汾��:" + packageInfo.versionCode);
		message.append("\n �汾��:" + packageInfo.versionName);
		
		builder.setMessage(message.toString());
		builder.setIcon(packageInfo.applicationInfo.loadIcon(getPackageManager()));
		builder.setPositiveButton("ȷ��", null);
		builder.create().show();
	}
    
}