
package yuqian.fileEncryption;

public class check {

	//����ַ����Ƿ�ǿ�
	public static boolean isNull(String s){
		if(s==null) return true;
		boolean r = true;
		for(int i=0;i<s.length();i++){
			if(s.substring(i, i+1).equals(" ")){
				continue;
			}
			else{
				r=false;
				break;
			}
		}
		return r;
	}
}
