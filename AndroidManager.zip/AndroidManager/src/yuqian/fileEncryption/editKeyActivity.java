package yuqian.fileEncryption;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import yuqian.androidmanager.R;
import yuqian.fileEncryption.FileSelectActivity.SelFileBtnListener;
import yuqian.fileEncryption.MainActivity.editKeyListener;
import yuqian.fileEncryption.MainActivity.menuDecryptBtnListener;
import yuqian.fileEncryption.MainActivity.menuEncryptBtnListener;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import yuqian.Defence.Avoid_list_db;
import yuqian.Defence.PhoneService;
import yuqian.FileManager.*;

public class editKeyActivity extends Activity {
	
	private Button editKey1;
	private EditText Text1;
	private EditText Text2;
	private EditText Text0;
	

	
	@Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.editkey);
        editKey1=(Button) this.findViewById(yuqian.androidmanager.R.id.button_09);
        Text0=(EditText) this.findViewById(yuqian.androidmanager.R.id.EditText_08);
        Text1=(EditText) this.findViewById(yuqian.androidmanager.R.id.EditText_09);
        Text2=(EditText) this.findViewById(yuqian.androidmanager.R.id.EditText_10);
        editKey1.setOnClickListener(new editKey1Listener());
    }
	
	 class editKey1Listener implements OnClickListener{
			@Override
			public void onClick(View v) {
				
				//��ó�ʼ����
				//String signkey="12345";
				
				SharedPreferences sp2 = editKeyActivity.this.getSharedPreferences("signwords", Context.MODE_PRIVATE);
				 String signkey = sp2.getString("key", "");//���ȡ����ֵ��ȡ�����""
				 	String sss=Text0.getText().toString();
				 	String sss1=sss.hashCode()+"";

			        System.out.println("�����룺"+sss);
			        System.out.println("�������hash��"+sss1);
			        System.out.println("��ȡ�������hash��"+signkey);
					/*byte[] digesta=null;
		    		try{
		    			MessageDigest alg = MessageDigest.getInstance("MD5");
		    			alg.update(sss.getBytes());
		    			digesta = alg.digest();
		    			sss=digesta.toString();
		    			}
		    		catch (NoSuchAlgorithmException e) {
		    				System.out.println("Error: MD5 failed 3");
		    			}*/
		    		
				//����޸Ĳ�����ȷ
				if(sss1.equals(signkey)&&Text1.getText().toString().equals(Text2.getText().toString()))
				{
					String ssss=Text1.getText().toString();
					signkey=ssss.hashCode()+"";
					System.out.println("�޸ĵ����룺"+ssss);
					System.out.println("�޸ĺ������hash��"+signkey);
					/*byte[] digesta2=null;
		    		try{
		    			MessageDigest alg = MessageDigest.getInstance("MD5");
		    			alg.update(signkey.getBytes());
		    			digesta2 = alg.digest();
		    			signkey=digesta2.toString();
		    			System.out.println("�޸ĺ��signkey"+signkey);
		    			}
		    		catch (NoSuchAlgorithmException e) {
		    				System.out.println("Error: MD5 failed 5");
		    			}*/
					
					SharedPreferences sp = getSharedPreferences("signwords", Context.MODE_PRIVATE);
				    Editor editor = sp.edit();       
				    editor.putString("key",signkey);
				    editor.commit();

							Toast toast = Toast.makeText(getApplicationContext(), "�����޸ĳɹ�", Toast.LENGTH_LONG);
					        toast.setGravity(Gravity.CENTER, 0, 0);
					        toast.show();
				}
					}
				}
			
			
			/*
			public void db_use()
			{
				key_db kd = new key_db(editKeyActivity.this, "key_db");
				SQLiteDatabase db = kd.getReadableDatabase();		
				Cursor cursor = db.query("keys", new String[]{"key"}, null, null, null, null, null);
					String mykey = cursor.getString(cursor.getColumnIndex("key"));	
					System.out.println("mykey: "+mykey);
					if(Text0.getText().toString().equals(mykey)&&Text1.getText().toString().equals(Text1.getText().toString()))
					{

						String s2=Text1.getText().toString();
						db.execSQL("update keys set key=s2");
						String mykey3 = cursor.getString(cursor.getColumnIndex("key"));					
						System.out.println("mykey: "+mykey3);
						kd.close();
						db.close();
						
						Toast toast = Toast.makeText(getApplicationContext(), "�����޸ĳɹ�", Toast.LENGTH_LONG);
				        toast.setGravity(Gravity.CENTER, 0, 0);
				        toast.show();
					}
					
					if((phoneNumber.equals(s_num)&&s_type.equals("2"))||(phoneNumber.equals(s_num)&&s_type.equals("3"))){
						Avoid_list_db list_db = new Avoid_list_db(PhoneService.this, "avoid_list_db");
						SQLiteDatabase l_db = list_db.getReadableDatabase();
						ContentValues values = new ContentValues();
						values.put("number", phoneNumber);
						values.put("time", time);
						values.put("content", "����");
						l_db.insert("in_content", null, values);
						System.out.println("lanjieduixiang");
						l_db.close();
						cursor.close();
						db.close();
						return true;
					}
	 }	*/
				
//				cursor.close();
//				db.close();
				
				//return false;
	 }
	// }
//}