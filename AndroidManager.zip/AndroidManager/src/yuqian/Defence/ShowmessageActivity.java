//�ѷ���1
package yuqian.Defence;

import yuqian.androidmanager.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;

//��ʾ����Activity
public class ShowmessageActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.show_message);
		EditText text = (EditText)findViewById(R.id.showmessage);
		Intent intent = getIntent();
		String message = intent.getStringExtra("message");
		text.setText(message);
	}

}
