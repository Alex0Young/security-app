package yuqian.Defence;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import yuqian.androidmanager.*;

import yuqian.androidmanager.R;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ExpandableListView;

//��������activity
public class RosterActivity extends Activity {

	List<String> groups ;
	
	//List���Map���Ͷ��󣬶���ֻ�ܷ�String���ͼ���Object����ֵ�ļ�ֵ�ԡ�
	List<Map<String,String>> children;
	ExpandableListView elv ;
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		super.onPause();
		Data_roster data_roster = this.get_data();
		groups.clear();
		children.clear();
		groups.addAll(data_roster.number);
		children.addAll(data_roster.num_type);
		ExpandableAdapter viewAdapter = new ExpandableAdapter(this, groups, children);
		elv.setAdapter(viewAdapter);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.roster);
		groups = new ArrayList<String>();
		children =new ArrayList<Map<String,String>>();
		Data_roster data_roster = this.get_data();
		groups.addAll(data_roster.number);
		children.addAll(data_roster.num_type);
		elv = (ExpandableListView)findViewById(R.id.roster_Expandable);
		ExpandableAdapter viewAdapter = new ExpandableAdapter(this, groups, children);
		elv.setAdapter(viewAdapter);
	}
	public Data_roster get_data(){
		Data_roster data_roster = new Data_roster();
		Map<String,String> map = new HashMap<String, String>();
		Avoid_roster_db roster_db = new Avoid_roster_db(RosterActivity.this, "avoid_roster_db");
		SQLiteDatabase db = roster_db.getReadableDatabase();
		Cursor cursor = db.query("in_message", new String[]{"number","type"}, null, null, null, null, null);
		while(cursor.moveToNext()){
			String num =cursor.getString(cursor.getColumnIndex("number"));
			data_roster.number.add(num);
			map.put(num, cursor.getString(cursor.getColumnIndex("type")));
			data_roster.num_type.add(map);
		}
		cursor.close();
		db.close();
		return data_roster;
	}
}
