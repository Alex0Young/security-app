package yuqian.Defence;

import android.content.BroadcastReceiver; 
import android.content.Context;
import android.content.Intent;

public class PhoneReciever extends BroadcastReceiver {

	
	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		Intent myintent = new Intent(context, PhoneService.class);  
        myintent.setAction("com.reciever.PhoneReciever");  
        context.startService(myintent);  
	}
}
