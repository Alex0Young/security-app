package yuqian.Defence;

import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.IBinder;

//��̨�������ݿ�
public class ChildService extends Service {

	//����onBind��onCreate�������ں���
	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		
		
	}

	//ÿ�ε���startService��ʱ�򣬶�����ø�Service�����onStartCommand����
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		String number =null;
		String type = null;
		Intent typeInten = intent;
		
		number = typeInten.getStringExtra("num");
		type = typeInten.getStringExtra("check");
		
		Avoid_roster_db roster_db = new Avoid_roster_db(ChildService.this, "avoid_roster_db");
		SQLiteDatabase db = roster_db.getReadableDatabase();
		ContentValues values = new ContentValues();
		values.put("type", type);
		db.update("in_message", values, "number=?", new String[]{number});//�������ݿ�
		db.close();
		return super.onStartCommand(intent, flags, startId);
	}
	

}
