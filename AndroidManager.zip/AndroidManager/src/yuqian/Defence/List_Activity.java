package yuqian.Defence;
import java.util.ArrayList;  
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import yuqian.Defence.Avoid_list_db;

import yuqian.androidmanager.R;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;

public class List_Activity extends Activity {

	ListView listview;
	SimpleAdapter simpleadapter;
	List<Map<String,String>> list_map;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list);
		listview=(ListView)findViewById(R.id.listView1);
		list_map = new ArrayList<Map<String,String>>();
		list_map.clear();
		Avoid_list_db list_db = new Avoid_list_db(List_Activity.this, "avoid_list_db");
		SQLiteDatabase db = list_db.getReadableDatabase();
		Cursor cursor = db.query("in_content", new String[]{"number","time"}, null, null, null, null, null);
		while(cursor.moveToNext()){
			HashMap<String, String> map = new HashMap<String, String>();
			String s_num = cursor.getString(cursor.getColumnIndex("number"));
			String s_time = cursor.getString(cursor.getColumnIndex("time"));
			map.put("time", s_time);
			map.put("number", s_num);
			list_map.add(map);
		}
		cursor.close();
		db.close();
		simpleadapter = new SimpleAdapter(this, list_map, R.layout.list_child, new String[]{"time","number"}, new int[]{R.id.time_textView,R.id.num_textView});
		listview.setAdapter(simpleadapter);
		
		
	}
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub\
		super.onResume();
		list_map.clear();
		Avoid_list_db list_db = new Avoid_list_db(List_Activity.this, "avoid_list_db");
		SQLiteDatabase db = list_db.getReadableDatabase();
		Cursor cursor = db.query("in_content", new String[]{"number","time"}, null, null, null, null, null);
		while(cursor.moveToNext()){
			HashMap<String, String> map = new HashMap<String, String>();
			String s_num = cursor.getString(cursor.getColumnIndex("number"));
			String s_time = cursor.getString(cursor.getColumnIndex("time"));
			map.put("time", s_time);
			map.put("number", s_num);
			list_map.add(map);
		}
		cursor.close();
		db.close();
		simpleadapter = new SimpleAdapter(this, list_map, R.layout.list_child, new String[]{"time","number"}, new int[]{R.id.time_textView,R.id.num_textView});
		listview.setAdapter(simpleadapter);
		
		listview.setOnItemClickListener(new List_click());
	}
	class List_click implements OnItemClickListener{
		
		@SuppressWarnings("unchecked")
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			// TODO Auto-generated method stub
			ListView listView = (ListView)arg0;
			HashMap<String, String> map = (HashMap<String, String>)listView.getItemAtPosition(arg2); 
			String num = map.get("number");
			Avoid_list_db list_db = new Avoid_list_db(List_Activity.this, "avoid_list_db");
			SQLiteDatabase db = list_db.getReadableDatabase();
			Cursor cursor = db.query("in_content", new String[]{"number","time","content"}, null, null, null, null, null);
			while(cursor.moveToNext()){
				String s_num = cursor.getString(cursor.getColumnIndex("number"));
				String s_time = cursor.getString(cursor.getColumnIndex("time"));
				String time = map.get("time");
				if(num.equals(s_num)&&time.equals(s_time)){
					String s_content = cursor.getString(cursor.getColumnIndex("content"));
					String message ="ʱ��:"+s_time+"\n"+"�绰���룺"+s_num+"\n"+"״̬:"+s_content;
					Intent intent = new Intent(List_Activity.this,ShowmessageActivity.class);
					intent.putExtra("message", message);
					startActivity(intent);
					
				}
			}
			cursor.close();
			db.close();
		}
		
	}

}
