package yuqian.Defence;

import yuqian.androidmanager.R;

import java.util.List;  
import java.util.Map;

import yuqian.androidmanager.*;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.RelativeLayout;
import android.widget.TextView;

//BaseExpandableListAdapter����������
public class ExpandableAdapter extends BaseExpandableListAdapter {
	final static int len=1;
	List<String> groups;
	Context context;
	List<Map<String,String>> childs;
	
	//���캯��
	public ExpandableAdapter(Context context, List<String> groups, List<Map<String,String>> childs)
	{
		this.context=context;
		this.groups=groups;
		this.childs=childs;
	}

	@Override
	public Object getChild(int arg0, int arg1) {
		// TODO Auto-generated method stub
		return childs.get(arg0).get(arg1);
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return childPosition;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		final String text = groups.get(groupPosition);
		final Data_check check = new Data_check();
		

		
		
		LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		RelativeLayout childLinelayout = (RelativeLayout)layoutInflater.inflate(R.layout.children, null);
		CheckBox msn_check = (CheckBox)childLinelayout.findViewById(R.id.child_checkmsn);
		CheckBox phone_check = (CheckBox)childLinelayout.findViewById(R.id.child_numCheck);
		Button okButton = (Button)childLinelayout.findViewById(R.id.changEnd_button);
		Map<String, String> map =childs.get(groupPosition);
		String type = map.get(groups.get(groupPosition));
		if(type.equals("1")){
			msn_check.setChecked(true);
			phone_check.setChecked(false);
			check.checkmsn=1;
		}
		if(type.equals("2")){
			msn_check.setChecked(false);
			phone_check.setChecked(true);
			check.checkphone=2;
		}
		if(type.equals("3")){
			msn_check.setChecked(true);
			phone_check.setChecked(true);
			check.checkmsn=1;
			check.checkphone=2;
		}
			
		
		//����check״̬
		
		msn_check.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				// TODO Auto-generated method stub
				if(isChecked){
					check.checkmsn=1;
				}
				else{
					check.checkmsn=0;
				}
					
			}
		});
		
		
		//����check״̬
		phone_check.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				// TODO Auto-generated method stub
				if(isChecked){
					check.checkphone=2;
				}
				else{
					check.checkphone=0;
				}
			}
		});
		
		
		
		
		//�����޸�����
		okButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String check_=String.valueOf(check.checkmsn+check.checkphone);
				System.out.println(check_);
				Intent intent = new Intent(context,ChildService.class);
				intent.setAction("com.reciever.ChildService");
				intent.putExtra("check", check_);
				intent.putExtra("num", text);
				context.startService(intent);
				
			}
		});
		//System.out.println(map.get(groups.get(groupPosition)));
		return childLinelayout;
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		// TODO Auto-generated method stub
		return len;
	}

	@Override
	public Object getGroup(int groupPosition) {
		// TODO Auto-generated method stub
		return groups.get(groupPosition);
	}

	@Override
	public int getGroupCount() {
		// TODO Auto-generated method stub
		return groups.size();
	}

	@Override
	public long getGroupId(int groupPosition) {
		// TODO Auto-generated method stub
		return groupPosition;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		String text = groups.get(groupPosition);
		LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		RelativeLayout groupLinelayout = (RelativeLayout)layoutInflater.inflate(R.layout.groups, null);
		TextView textview = (TextView) groupLinelayout.findViewById(R.id.group);
		textview.setText(text);
//		Intent intent = new Intent(context,ChildActivity.class);
//		intent.putExtra("phoneNumber", text);
//		context.s
		//��ȡһ���б������ļ�,������ӦԪ������
		return groupLinelayout;
	}

	@Override
	public boolean hasStableIds() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return true;
	}
	

}
