
//��������������
package yuqian.Defence;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Data_roster {

	public List<String> number;
    public List<Map<String,String>> num_type;
    public Data_roster(){
    	number=new ArrayList<String>();
    	 num_type= new ArrayList<Map<String,String>>();
    }
}
