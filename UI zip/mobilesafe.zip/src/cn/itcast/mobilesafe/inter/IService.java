package cn.itcast.mobilesafe.inter;

public interface IService {

	public void addTemp(String packageName);
}
