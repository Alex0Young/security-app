package com.example.mobliemanager.activity;

import java.lang.reflect.Field;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.view.Window;
import android.widget.Toast;

import com.example.mobliemanager.application.SysApplication;

public class BaseActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		((SysApplication) getApplication()).addActivity(this);
		super.onCreate(savedInstanceState);
	}

	protected void openActivity(Class<?> cls, Bundle bundle) {
		Intent intent = new Intent();
		intent.setClass(this, cls);
		intent.putExtras(bundle);
		startActivityForResult(intent, 1);
	}

	// Activity��ת
	protected void openActivity(Class<?> cls) {
		Intent intent = new Intent();
		intent.setClass(this, cls);
		startActivityForResult(intent, 1);
	}

	// Activity��ת
	protected void openActivity(Class<?> cls, Boolean flags) {
		openActivity(cls);
		if (flags) {
			this.finish();
		}
	}

	/**
	 * ������ֵ�ͽ����� �ر�Activity
	 * 
	 * @param data
	 * @param resultCode
	 */
	protected void finishActivity(Intent data, int resultCode) {
		setResult(resultCode, data);
		this.finish();
	}

	Handler handler = new Handler() {

		@Override
		public void handleMessage(Message msg) {

			switch (msg.what) {

			case Toast.LENGTH_LONG:
				Toast.makeText(BaseActivity.this, (String) msg.obj,
						Toast.LENGTH_LONG).show();
				break;
			case Toast.LENGTH_SHORT:
				Toast.makeText(BaseActivity.this, (String) msg.obj,
						Toast.LENGTH_SHORT).show();
				break;

			default:
				break;
			}
			super.handleMessage(msg);
		}

	};

	// ��ʾ��ʱ��Toast��ʾ
	protected void showToastLong(CharSequence text) {
		Message message = handler.obtainMessage();
		message.obj = text;
		message.what = Toast.LENGTH_LONG;
		handler.sendMessage(message);
	}

	// ��ʾ��ʱ��Toast��ʾ
	protected void showToastShort(CharSequence text) {
		Message message = handler.obtainMessage();
		message.obj = text;
		message.what = Toast.LENGTH_SHORT;
		handler.sendMessage(message);
		// Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}

	/**
	 * �õ���Ļ�Ŀ���
	 */
	protected int getWindowsWidth() {
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int width = dm.widthPixels;
		return width;
	}

	/**
	 * �õ���Ļ�ĸ߶�
	 */
	protected int getWindowsHeight() {
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int height = dm.heightPixels;
		return height;
	}
	
	/**
	 * �õ�֪ͨ���ĸ߶�
	 */
	public int getStatusBarHeight(Context context) {
		Class<?> c = null;
		Object obj = null;
		Field field = null;
		int x = 0, statusBarHeight = 0;
		try
		{
			c = Class.forName("com.android.internal.R$dimen");
			obj = c.newInstance();
			field = c.getField("status_bar_height");
			x = Integer.parseInt(field.get(obj).toString());
			statusBarHeight = context.getResources().getDimensionPixelSize(x);
		} catch
		(Exception e1) {
			e1.printStackTrace();
		}
		return statusBarHeight;
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		((SysApplication) getApplication()).removeActivity(this);

	}

}
