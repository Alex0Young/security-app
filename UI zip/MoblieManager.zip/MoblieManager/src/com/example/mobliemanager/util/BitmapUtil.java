package com.example.mobliemanager.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;

import org.json.JSONArray;
import org.json.JSONException;

import com.example.mobliemanager.common.ConstantPool;


import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.util.Base64;

/**
 * ͼƬ�ӹ�������
 *
 * @author ligj
 *
 */
public class BitmapUtil {

	/**
	 * ͼƬ����
	 */
	private final static int QUALITY = 100;

	/**
	 * Bitmapתbase64
	 *
	 * @param bitmap
	 *            λͼ
	 * @return �ַ���
	 */
	public static String bitmaptoString(Bitmap bitmap) {
		String str = "";
		ByteArrayOutputStream bStream = new ByteArrayOutputStream();
		if (bitmap != null) {
			bitmap.compress(CompressFormat.PNG, QUALITY, bStream);
			byte[] bytes = bStream.toByteArray();
			str = Base64.encodeToString(bytes, Base64.DEFAULT);
		}
		return str;
	}

	/**
	 * bitmap ת�ֽ�����
	 * @param bitmap
	 * @return
	 */
	public static byte[] bitmaptoBytes(Bitmap bitmap){
		ByteArrayOutputStream bStream = new ByteArrayOutputStream();
		if (bitmap != null) {
			bitmap.compress(CompressFormat.PNG, QUALITY, bStream);
			byte[] bytes = bStream.toByteArray();
			return bytes;
		}
		return null;
	}

	/**
	 * ���ַ���ת����Bitmap����
	 *
	 * @param str
	 *            �ַ���
	 * @return λͼ
	 */
	public static Bitmap stringtoBitmap(String str) {
		Bitmap bitmap = null;
		byte[] bitmapArray = stringtoBytes(str);
		if (bitmapArray != null) {
			bitmap = BitmapFactory.decodeByteArray(bitmapArray, 0,
					bitmapArray.length);
		}
		return bitmap;
	}

	/**
	 * ���ַ���ת����byte����
	 *
	 * @param str
	 *            �ַ���
	 * @return byte����
	 */
	public static byte[] stringtoBytes(String str) {
		if (StringUtil.stringIsNotNull(str)) {
			return Base64.decode(str, Base64.DEFAULT);
		} else {
			return null;
		}
	}

	/**
	 * bitmap���汾��
	 *
	 * @param bmp
	 *            ͼƬ
	 * @param filename
	 *            �ļ�·��
	 * @return �Ƿ񱣴�ɹ�
	 * @throws FileNotFoundException
	 *             �ļ��������쳣
	 */
	public static boolean saveBitmapFile(Bitmap bmp, String filename)
			throws FileNotFoundException {
		CompressFormat format = Bitmap.CompressFormat.PNG;
		OutputStream stream = null;
		if (StringUtil.stringIsNotNull(filename) && bmp != null) {
			stream = new FileOutputStream(filename);
		} else {
			return false;
		}
		return bmp.compress(format, QUALITY, stream);
	}

	/**
	 * ����ͼƬ��ȡ
	 *
	 * @param pathString
	 *            ·��
	 * @return λͼ
	 * @throws FileNotFoundException
	 *             �ļ��������쳣
	 */
	public static Bitmap getDiskBitmap(String pathString)
			throws FileNotFoundException {
		Bitmap bitmap = null;
		if (StringUtil.isEmpty(pathString)) {
			return null;
		}
		File file = new File(pathString);
		if (file.exists()) {
			bitmap = BitmapFactory.decodeFile(pathString);
		} else {
			return null;
		}
		return bitmap;
	}

	/**
	 * ����ͼƬɾ��
	 *
	 * @param pathString
	 *            ·��
	 * @return �Ƿ�ɾ���ɹ�
	 * @throws Exception
	 *             ɾ���쳣
	 */
	public static boolean delDiskBitmap(String pathString) {
		if (StringUtil.isEmpty(pathString)) {
			return false;
		}
		File file = new File(pathString);
		if (file.exists()) {
			file.delete();
			return true;
		}
		return false;
	}

	/**
	 * �����ļ���ɾ��
	 *
	 * @param pathString
	 *            ·��
	 * @return �Ƿ�ɾ���ɹ�
	 * @throws Exception
	 *             ɾ���쳣
	 */
	public static boolean delDirectory(String pathString) {
		if (StringUtil.isEmpty(pathString)) {
			return false;
		}
		File file = new File(pathString);
		if (file.exists()) {
			if (!file.isDirectory()) {
				// ��������ļ��� ɾ�������ļ�
				return delDiskBitmap(pathString);
			} else {
				// ������ļ��� �ݹ�ɾ��
				File[] files = file.listFiles();
				for (int i = 0; i < files.length; i++) {
					if (files[i].isFile()) {
						// ɾ�����ļ�
						delDiskBitmap(files[i].getAbsolutePath());
					} else {
						// ɾ����Ŀ¼
						delDirectory(files[i].getAbsolutePath());
					}
				}
				if (file.delete()) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * ���벢����ͼƬ
	 *
	 * @param imgsArray
	 *            ͼƬjson����
	 * @param fileType
	 *            ͼƬ��������ģ��
	 * @param assignNo
	 *            ����
	 * @return �ļ�·��
	 * @throws JSONException
	 *             JSON�쳣
	 * @throws FileNotFoundException
	 *             �ļ�δ�ҵ��쳣
	 */
	public static String decodeSaveImgs(JSONArray imgsArray, String fileType,
			String assignNo) throws JSONException, FileNotFoundException {
		StringBuffer path = null;
		Bitmap bitmap = null;
		// ͼƬλ��
		String bitmapPath = "";
		if (null != imgsArray && imgsArray.length() > 0) {
			for (int i = 0; i < imgsArray.length(); i++) {
				// ƴ����Ƭ�洢·��
				path = new StringBuffer();
				path.append(ConstantPool.SD_PATH)
						.append(ConstantPool.ASSIGNMENT).append(assignNo)
						.append(File.separator)
						.append(ConstantPool.TMPIMAGE_PATH).append(fileType)
						.append(File.separator);
				// �����ļ���
				File file = new File(path.toString());
				if (!file.exists()) {
					file.mkdirs();
				}
				// ��ʱ����Ϊ�ļ��������ļ�
				String picName = DateUtil
						.getCurrentDate(DateUtil.DATE_PATTERN_6);
				path.append(picName + i).append(".png");
				byte[] bitmapArray = stringtoBytes(imgsArray.getString(i));
				if (bitmapArray != null) {
					bitmap = BitmapFactory.decodeByteArray(bitmapArray, 0,
							bitmapArray.length);
					saveBitmapFile(bitmap, path.toString());
					if (null != bitmap && !bitmap.isRecycled()) {
						bitmap.recycle();
						bitmap = null;
					} else if (null == bitmap) {
						continue;
					}
					bitmapPath = bitmapPath + path.toString();
					if (i != (imgsArray.length() - 1)) {
						bitmapPath = bitmapPath + ";";
					}
				}

			}
		}
		return bitmapPath;
	}
	
	/**
	 * ����ͼƬ
	 * @param f
	 * @return
	 */
    public static Bitmap decodeFile(File f){
        try {
            //decode image size
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(new FileInputStream(f),null,o);
            
            //Find the correct scale value. It should be the power of 2.
            final int REQUIRED_SIZE=70;
            int width_tmp=o.outWidth, height_tmp=o.outHeight;
            int scale=1;
            while(true){
                if(width_tmp/2<REQUIRED_SIZE || height_tmp/2<REQUIRED_SIZE)
                    break;
                width_tmp/=2;
                height_tmp/=2;
                scale*=2;
            }
            
            //decode with inSampleSize
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize=scale;
            return BitmapFactory.decodeStream(new FileInputStream(f), null, o2);
        } catch (FileNotFoundException e) {}
        return null;
    }
}