package com.example.mobliemanager.util;

import android.util.Log;

/**
 * @author tz_xucg
 * 
 */
public class L {
	private static final String TAG = "bdyd";

	public static boolean isDebug = false;
	public static String getName(Class context) {
		return context.getSimpleName();
	}
//	public static void i(String msg) {
//		if(StringUtil.isEmpty(msg))
//			msg = "���ִ���";
//		if (isDebug)
//			L.i(TAG, msg);
//	}
//
//	public static void d(String msg) {
//		if(StringUtil.isEmpty(msg))
//			msg = "���ִ���";
//		if (isDebug)
//			L.d(TAG, msg);
//	}
//
//	public static void e(String msg) {
//		if(StringUtil.isEmpty(msg))
//			msg = "���ִ���";
//		if (isDebug)
//			L.e(TAG, msg);
//	}
//
//	public static void v(String msg) {
//		if(StringUtil.isEmpty(msg))
//			msg = "���ִ���";
//		if (isDebug)
//			L.v(TAG, msg);
//	}

	public static void i(String tag, String msg) {
		if(StringUtil.isEmpty(msg))
			msg = "���ִ���";
		if (isDebug)
			Log.i(tag, msg);
	}

	public static void d(String tag, String msg) {
		if(StringUtil.isEmpty(msg))
			msg = "���ִ���";
		if (isDebug)
			Log.i(tag, msg);
	}

	public static void e(String tag, String msg) {
		if(StringUtil.isEmpty(msg))
			msg = "���ִ���";
		if (isDebug)
			Log.i(tag, msg);
	}

	public static void v(String tag, String msg) {
		if(StringUtil.isEmpty(msg))
			msg = "���ִ���";
		if (isDebug)
			Log.i(tag, msg);
	}
}
