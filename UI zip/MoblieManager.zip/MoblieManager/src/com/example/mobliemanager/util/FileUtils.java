package com.example.mobliemanager.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

import com.example.mobliemanager.common.ConstantPool;

import android.os.Environment;


/**
 * 文件操作工具类
 * @author liuyw
 *
 */
public class FileUtils {

	/**
	 * 记录操作日志
	 * @param time
	 * @param msg
	 */
	public static void logOut(String time, String msg) {
		try {
			String fileName = "log" + DateUtil.getCurrentDate(DateUtil.DATE_PATTERN_9) + ".txt";
			String logFile = FileUtils.getPATH() + ConstantPool.LOGDIR + fileName;
			if (!FileUtils.isFileExist(logFile)) {
				createDir(ConstantPool.LOGDIR);
				createFile(ConstantPool.LOGDIR + fileName);
			}
			FileWriter writer = new FileWriter(new File(
					logFile), true);
			writer.write("TIME:----->" + time + "        msg:---->" + msg + "\r\n");
			writer.close();
			//清除过期7天的日志文件
			destoryLogFile();
		} catch (Exception e) {
			L.e("FileUtils",e.getMessage());
		}
		
	}
	
	/**
	 * 删除7天过期log文件
	 */
	public static void destoryLogFile() {
		String dir = FileUtils.getPATH() + ConstantPool.LOGDIR;
		File dirFile = new File(dir);
		File[] logFiles = dirFile.listFiles();
		// 当前时间
		Date currentDate = new Date();
		for (int i = 0; i < logFiles.length; i++) {
			File logFile = logFiles[i];
			Date fileDate = new Date(logFile.lastModified());
			// 如果没有带日期的文件则不处理
			if (fileDate != null) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(fileDate);
				cal.add(Calendar.DATE, 7);
				Date matchTime = cal.getTime();
				// 文件时间+6天是否小于当前日期
				if (matchTime.before(currentDate)) {
					// 符合条件的文件删除
					if (logFile.exists()) {
						 logFile.delete();
					}
				}
			}
		}
	}
	
	/**
	 * 记录异常消息
	 * @param e
	 */
	public static void logOutError(Exception e) {
		try {
			String fileName = "logError" + DateUtil.getCurrentDate(DateUtil.DATE_PATTERN_9) + ".txt";
			String logFile = FileUtils.getPATH() + ConstantPool.LOGDIR + fileName;
			if (!FileUtils.isFileExist(logFile)) {
				createDir(ConstantPool.LOGDIR);
				createFile(ConstantPool.LOGDIR + fileName);
			}
			FileWriter writer = new FileWriter(new File(logFile), true);
			writer.write("TIME:----->" + DateUtil.getCurrentDate(DateUtil.DATE_PATTERN_8) + "\r\n");
			writer.close();
			
		} catch (Exception e1) {
			L.e("FileUtils",e1.getMessage());
		}
	}

	/**
	 * 取得sd卡目录路径
	 * @return
	 */
	public static String getPATH() {
		// 判断sd卡是否存在并且可读写
		boolean sdCardExist = Environment.getExternalStorageState().equals(
				android.os.Environment.MEDIA_MOUNTED);
		// 如果有sd卡存在并且可写则将数据存放在sd,否则放在data目录下
		if (sdCardExist) {
			return Environment.getExternalStorageDirectory() + File.separator;
		} else {
			return Environment.getDataDirectory().getAbsolutePath()
					+ File.separator;
		}

	}

	/**
	 * 创建文件
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	public static File createFile(String fileName) throws IOException {
		File file = new File(getPATH() + fileName);
		file.createNewFile();
		return file;
	}

	/**
	 * 创建目录
	 * @param dirName
	 * @return
	 */
	public static File createDir(String dirName) {
		File dir = new File(getPATH() + dirName);
		dir.mkdirs();
		return dir;
	}

	/**
	 * 判断文件是否存在
	 * @param fileName 文件完整路径
	 * @return
	 */
	public static boolean isFileExist(String fileName) {
		File file = new File(fileName);
		return file.exists();
	}
	
	
	/**
	 * 读取文件里的内容
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	public static String readFile(String fileName) {
		// 数据
		String data = "";
		// 文件
		File file = new File(fileName);
		// 缓冲流
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			// 一次读入一行，直到读入null为文件结束
			while ((tempString = reader.readLine()) != null) {
				if (!tempString.equals("")) {
					data = data + tempString;
				}
			}
			reader.close();
			if (reader != null) {
				reader.close();
			}
		} catch (FileNotFoundException e) {
			L.e("FileUtils", e.getMessage());
			return null;
		} catch (IOException e) {
			L.e("FileUtils", e.getMessage());
			return null;
		}
		return data;
	}
	
	/**
	 * 删除指定路径文件
	 * @param fileName
	 * @throws IOException
	 */
	public static boolean deleteFile(String fileName){
		File file = new File(fileName);
		//如果文件存在
		if(file.exists()){
			//删除文件
			return file.delete();
		}
		return false;
	}
	

	/**
	 * 写入文件内容
	 * @param fileName 文件名
	 * @param content  写入内容
	 * @throws IOException 
	 */
    public static String writerFile(String fileName, String content){
		StringBuffer path = new StringBuffer();// 存储路径
		path.append(ConstantPool.SD_PATH);
		path.append(ConstantPool.DATA_PATH);
		path.append(fileName);
		path.append(".txt");
		try {
			//打开一个写文件器
			FileWriter writer = new FileWriter(path.toString());
			//写入内容
			writer.write(content);
			writer.close();
		} catch (IOException e) {
			L.e("FileUtils", e.getMessage());
			return null;
		}
		return path.toString();
    }
    
	/**
	 * 根据路径删除图片
	 * @param isAll
	 * @param pathAssignNo
	 * @return
	 */
	public static boolean delPic(boolean isAll,String pathAssignNo){
		boolean flag;
		if (isAll) {
			// 拼出文件夹路径删除故障照片
			StringBuffer root = new StringBuffer();
			root.append(ConstantPool.SD_PATH)
					.append(ConstantPool.ASSIGNMENT).append(pathAssignNo)
					.append("/");
			flag = BitmapUtil.delDirectory(root.toString());
		} else {
			// 删除
			flag = BitmapUtil.delDirectory(pathAssignNo);
		}
		return flag;
	}
}
