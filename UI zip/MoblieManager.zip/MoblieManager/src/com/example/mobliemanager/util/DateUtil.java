package com.example.mobliemanager.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {
	/** ��ʽ(yyyy/MM/dd) */
	public static final String DATE_PATTERN_1 = "yyyy/MM/dd";

	/** ��ʽ(yy/MM/dd) */
	public static final String DATE_PATTERN_2 = "yy/MM/dd";

	/** ��ʽ(yy/MM/dd HH:mm) */
	public static final String DATE_PATTERN_3 = "yy/MM/dd HH:mm";

	/** ��ʽ(yyyy/MM/dd HH:mm) */
	public static final String DATE_PATTERN_4 = "yyyy/MM/dd HH:mm";

	/** ��ʽ(yyyy/MM/dd HH:mm:ss) */
	public static final String DATE_PATTERN_5 = "yyyy/MM/dd HH:mm:ss";
	/** ��ʽ(yyMMddHHmmss) ����Σ��Դ|ȱ�ݱ�� */
	public static final String DATE_PATTERN_6 = "yyMMddHHmmss";

	/** ��ʽ(yyyy/MM/dd HH:mm:sssss) */
	public static final String DATE_PATTERN_7 = "yyyy/MM/dd HH:mm:sssss";

	/** ��ʽ(yyyy/MM/dd HH:mm:ss:SSS) */
	public static final String DATE_PATTERN_8 = "yyyy/MM/dd HH:mm:ss:SSS";

	/** ��ʽ(yyyyMMddHH) */
	public static final String DATE_PATTERN_9 = "yyyyMMddHH";

	/** ��ʽ(yyyy-MM-dd HH:mm:ss) */
	public static final String DATE_PATTERN_10 = "yyyy-MM-dd HH:mm:ss";

	/** ��ʽ(yyyy-MM-dd HH:mm) */
	public static final String DATE_PATTERN_11 = "yyyy-MM-dd HH:mm";
	
	/** ��ʽ(yyyy/MM/dd) */
	public static final String DATE_PATTERN_12 = "yyyy-MM-dd";

	/**
	 * ����ָ���ĸ�ʽ�����ڽ��и�ʽ������
	 * 
	 * @param date
	 *            ����
	 * @param format
	 *            ��ʽ
	 * @return ����
	 */
	public static String formatDate(Date date, String format) {
		if (null == date) {
			return null;
		}
		SimpleDateFormat df = (SimpleDateFormat) DateFormat.getDateInstance();
		df.applyPattern(format);
		return df.format(date);
	}

	/**
	 * ��ȡָ����ʽ��ϵͳʱ��
	 * 
	 * @param format
	 *            ��ʽ
	 * @return ����
	 */
	public static String getCurrentDate(String format) {
		Calendar cal = Calendar.getInstance();
		Date date = cal.getTime();
		return formatDate(date, format);
	}

	/**
	 * ��������ַ���ת����ָ����ʽ��������
	 * 
	 * @param date
	 *            ��������ڣ�����Ϊ�գ�
	 * @param format
	 *            ��ʽ
	 * @return ����
	 */
	public static Date toDate(String date, String format) {
		if (StringUtil.isEmpty(date)) {
			return null;
		}
		try {
			SimpleDateFormat df = (SimpleDateFormat) DateFormat
					.getDateInstance();
			df.applyPattern(format);
			return df.parse(date);
		} catch (ParseException e) {
			return null;
		}
	}

	/**
	 * ��������ַ���ת����"yyyy-MM-dd HH��mm"���ڵĸ�ʽ������
	 * 
	 * @param date
	 *            ��������ڣ�����Ϊ�գ�
	 * @param format
	 *            ��ʽ
	 * @return ����
	 */
	public static String toDateYMDHM(String date) {
		if (date != null) {
			Date date2 = toDate(date, "yyyy-MM-dd HH:mm");
			return formatDate(date2, "yyyy-MM-dd HH:mm");
		}
		return "";

	}
	public static String toDateYMD(String date) {
		if (date != null) {
			Date date2 = toDate(date, "yyyy-MM-dd");
			return formatDate(date2, "yyyy-MM-dd");
		}
		return "";

	}
	public static String toDateYMDHMs(String date) {
		if (date != null) {
			Date date2 = toDate(date, "yyyy-MM-dd HH:mm:ss");
			return formatDate(date2, "yyyy-MM-dd HH:mm:ss");
		}
		return "";

	}
	/**
	 * ��ȡָ����ʽ��ϵͳʱ��
	 * 
	 * @return ָ����ʽ��ϵͳʱ��
	 */
	public static String getSysdateStr() {
		return getCurrentDate(DATE_PATTERN_8);
	}

	/**
	 * ����һ��"yyyyMMddHHmmss"���ڵĸ�ʽ������
	 * 
	 * @return "yyyyMMddHHmmss"���ڵĸ�ʽ������
	 */
	private static SimpleDateFormat newShortYMDHMSFormat() {
		return new SimpleDateFormat("yyyyMMddHHmmss");
	}

	/**
	 * ����һ��"yyyy-MM-dd HH:mm:ss"���ڵĸ�ʽ������
	 * 
	 * @return "yyyy-MM-dd HH:mm:ss"���ڵĸ�ʽ������
	 */
	private static SimpleDateFormat newLongYMDHMSFormat() {
		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	}

	/**
	 * "yyyy-MM-dd HH:mm:ss"��ʽ������ת��Ϊ"yyyyMMddHHmmss"��ʽ������
	 * 
	 * @param longYMDHMS
	 *            "yyyy-MM-dd HH:mm:ss"��ʽ������
	 * @return "yyyyMMddHHmmss"��ʽ������
	 * @throws ParseException
	 */
	public static String toShortYMDHMS(String longYMDHMS) {
		try {
			return newShortYMDHMSFormat().format(
					newLongYMDHMSFormat().parse(longYMDHMS));
		} catch (ParseException e) {
			L.e("DateUtil",e.getMessage());
		}
		return longYMDHMS;
	}

	/**
	 * ��ȡָ��ʱ���뵱ǰʱ��ļ���� day��hourʱ��
	 * 
	 * @param assignTime
	 * @return
	 */
	public static String getPassedTime(String assignTime) {
		String result = "0ʱ";
		try {
			Date assignDate = toDate(assignTime, DateUtil.DATE_PATTERN_10);
			if (assignDate == null) {
				return result;
			}
			Calendar cal = Calendar.getInstance();
			Date nowDate = cal.getTime();
			long spareTime = nowDate.getTime() - assignDate.getTime();
			if (spareTime > 0) {
				long minute = spareTime / (60 * 1000) % 60;
				long hour = spareTime / (60 * 60 * 1000) % 24;
				long day = spareTime / (24 * 60 * 60 * 1000);
				if (day == 0 && hour == 0) {
					result = minute + "��";
				} else if (day == 0) {
					result = hour + "ʱ" + minute + "��";
				} else {
					result = day + "��" + hour + "ʱ" + minute + "��";
				}
			}
		} catch (Exception e) {
			L.e("DateUtil",e.getMessage());
		}
		return result;
	}

	/**
	 * ��ǰʱ����Ϸ���֮���ʱ��
	 * 
	 * @param minute
	 * @return
	 */
	public static String nowAddMinute(int minute) {
		String result = getCurrentDate(DATE_PATTERN_10);
		try {
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MINUTE, minute);
			Date newDate = cal.getTime();
			result = formatDate(newDate, DATE_PATTERN_10);
		} catch (Exception e) {
			L.e("DateUtil",e.getMessage());
		}
		return result;
	}
	
	
	/**
	 * ����ʱ���ʽ�ַ���ת��Ϊʱ�� yyyy-MM-dd HH:mm:ss
	 * 
	 */
	public static String getStringDate(Long date) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateString = formatter.format(date);

		return dateString;
	}

	
	/**
	 * ����ʱ���������֮���ʱ��
	 * @param minute
	 * @return
	 */
	public static String dateAddDay(String nowDate,int day) {
		String result  = nowDate;
		try {
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DAY_OF_YEAR, day);
			Date newDate = cal.getTime();
			result = formatDate(newDate, DATE_PATTERN_10);
		} catch (Exception e) {
			L.e("DateUtil",e.getMessage());
		}
		return result;
	}
	
	/**
	 * ����ʱ���������֮���ʱ��,����"yyyy-MM-dd"��ʽ
	 * @param minute
	 * @return
	 */
	public static String dateAddDayYMD(String nowDate,int day) {
		String result  = nowDate;
		try {
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DAY_OF_YEAR, day);
			Date newDate = cal.getTime();
			result = formatDate(newDate, DATE_PATTERN_12);
		} catch (Exception e) {
			L.e("DateUtil",e.getMessage());
		}
		return result;
	}
	
	/**
	 * ��ʼʱ��Ϊ���µ�һ�죬����ʱ��Ϊ����
	 * @param sjlx
	 * @return
	 */
	public static String dateType(String sjlx){
		SimpleDateFormat sDateFormat= new SimpleDateFormat("yyyy-MM-dd");
		String date = sDateFormat.format(new java.util.Date());
		if("but_kssj".equals(sjlx)||"jhzxsj_start".equals(sjlx)){
			date = date.substring(0, 7)+"-01";
		}
		return date;
	}
	
	public static String dateTimeType(String sjlx){
		SimpleDateFormat sDateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm");
		String date = sDateFormat.format(new java.util.Date());
		if("but_kssj".equals(sjlx)){
			date = date.substring(0, 7)+"-01";
		}
		return date;
	}
	/**
	 * �������һ��
	 */
	public static String LastDayofMonth(String sjlx){
		SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String date = sDateFormat.format(new java.util.Date());
		int year =new Date().getYear();
		int month = (new Date().getMonth())+1;
		String day = "";
		if(month==1||month==3||month==5||month==7||month==8||month==10||month==12){
			day="31";
		}
		if(month==4||month==6||month==9||month==11){
			day="30";
		}
		if(month==2){
			if((year%4==0&&year%100!=0)||(year%400==0)){
				day="29";
			}else{
				day="28";
			}
		}
		date = date.substring(0, 7)+"-"+day;
		return date;
	}
}
