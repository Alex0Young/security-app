package com.example.mobliemanager.application;

import java.lang.Thread.UncaughtExceptionHandler;
import java.util.LinkedList;
import java.util.List;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.net.ConnectivityManager;

import com.example.mobliemanager.util.L;

/**
 * ϵͳApplication����Activity����
 * 
 * @author xuezd
 * 
 */
public class SysApplication extends Application implements UncaughtExceptionHandler{
	
	public static final String YCEXIT = "YCEXIT";
	public static final String ZCEXIT = "ZCEXIT";
	
	public static final String TAG = "SysApplication";

	// Context����
	private Context mContext;
	// Activity�б�
	private List<Activity> list = new LinkedList<Activity>();
	private Throwable ex;
	private List<String> videoList;

	public List<String> getVideoList() {
		return videoList;
	}

	public void setVideoList(List<String> videoList) {
		this.videoList = videoList;
	}

	private List<String> recordList;

	public List<String> getRecordList() {
		return recordList;
	}

	public void setRecordList(List<String> recordList) {
		this.recordList = recordList;
	}

	// ��Activity����Listջ����
	public void addActivity(Activity activity) {
		list.add(activity);

	}

	// ��Activit�Ƴ�Listջ����
	public void removeActivity(Activity activity) {
		if (activity != null) {
			list.remove(activity);
			activity.finish();
			activity = null;
		}
	}

	// �˳�Ӧ��
	public void exit(String flag) {
		//��ֵ��������ʱ������
//		SharedPreferenceUtil.sharedPreferenceUtil
//				.removeKey(SharedPreferenceUtil.USER_SPORGID);
		try {
			for (Activity activity : list) {
				if (activity != null) {
					activity.finish();
				}
			}
		} catch (Exception e) {
		} finally {
			if (flag.equals(ZCEXIT)) {
				System.exit(0);
			} else {
//				if (isNetWorkAvailable(mContext)) {
//					Intent logRecordSaveService = new Intent(this,
//							LogRecordSaveService.class);
//					logRecordSaveService.putExtra(
//							LogRecordSaveService.CLASS_NAME, ex.getClass()
//									.getSimpleName());
//					logRecordSaveService.putExtra(
//							LogRecordSaveService.ERR_INFO, ex.getMessage());
//					logRecordSaveService.putExtra(
//							LogRecordSaveService.METHOD_NAME,
//							String.valueOf(ex.getCause()));
//					logRecordSaveService.putExtra(
//							LogRecordSaveService.EXIT_FLAG, true);
//					startService(logRecordSaveService);
//
//				} else {
//					android.os.Process.killProcess(android.os.Process.myPid());
//					System.exit(0);
//				}
				android.os.Process.killProcess(android.os.Process.myPid());
				System.exit(0);
			}
		}

	}
	
	/**
	 * �쳣��������
	 */
	@Override
	public void uncaughtException(Thread thread, Throwable ex) {
		// �ύ
		doCrashReport(thread, ex);
	}

	/**
	 * �ϱ�������Ϣ
	 * 
	 * @param report
	 */
	private void doCrashReport(Thread thread, Throwable ex) {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				L.e(TAG, e.getMessage());
			}

			// �˳�����
			exit(YCEXIT);
	}

	/**
	 * ����
	 */
	@Override
	public void onCreate() {
		super.onCreate();
		mContext = getApplicationContext();

	}

	@Override
	public void onLowMemory() {
		super.onLowMemory();
		System.gc();
	}
	
	public Boolean isNetWorkAvailable(Context mContext) {
		boolean flag = false;
		ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		if (manager.getActiveNetworkInfo() != null) {
			flag = manager.getActiveNetworkInfo().isAvailable();
		}
		return flag;

	}

}
